
<?php
$conn= mysqli_connect("localhost","root","","voting");
if(!$conn){
    die("connedctio failed".mysqli_connect_err());
}
?>