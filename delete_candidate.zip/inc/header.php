<?php
session_start();
if(!isset($_SESSION["user"])){
    echo "<script> alert('you must login first'); location.href='index.php'; </script> ";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SmartVote Dashboard</title>
  <style>
  .nav-link {
  color: black !important;
}
    </style>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="#">SmartVote</a>
      <div class="collapse navbar-collapse justify-content-end">
        <ul class="navbar-nav">
        <?php if($_SESSION["user"]["role"]=="ADMIN"){
?>
          <li class="nav-item"><a class="nav-link" href="#">Admin</a></li>
          <li class="nav-item"><a class="nav-link" href="candidates.php">Candidates</a></li>
          <li class="nav-item"><a class="nav-link" href="posts.php">posts</a></li>
          <li class="nav-item"><a class="nav-link" href="votters.php">Votters</a></li>
          <li class="nav-item"><a class="nav-link" href="report.php">Report</a></li>
        
    <?php    } ?>

          <li class="nav-item"><a class="nav-link" href="change_password.php">change password</a></li>
          <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <main class="container my-5">