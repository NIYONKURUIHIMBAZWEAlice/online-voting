
<?php
require_once 'inc/conn.php';
require_once 'inc/utils.php';

$data=getdata("SELECT * FROM users");
 echo "<ol>";
 foreach($data as $user){
    // die(var_dump($user));
     echo "<li>".$user['user_name']."</li>";
}
echo "</ol>";
// 
$data=getdata("SELECT * FROM votters");
 echo "<ol>";
 foreach($data as $user){
    // die(var_dump($user));
     echo "<li>".$user['fullname']."</li>";
}
echo "</ol>";
// 


?>